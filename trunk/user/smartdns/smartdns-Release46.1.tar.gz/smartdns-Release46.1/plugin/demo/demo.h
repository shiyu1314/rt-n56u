
#ifndef SMART_DNS_PLUGIN_DEMO_H
#define SMART_DNS_PLUGIN_DEMO_H

#include "dns_plugin.h"

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */


#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
