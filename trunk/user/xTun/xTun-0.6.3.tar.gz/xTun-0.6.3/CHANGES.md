v0.6.3 (2020-1-05)
-----------
* Feature: support padavan


v0.6.2 (2019-10-25)
-----------
* Change: README


v0.6.1 (2019-10-25)
-----------
* Feature: set tcp socket option
* Feature: auto set interface name


v0.6.0 (2019-6-01)
-----------
* Change: chacha20poly1305 instead of salsa208poly1305


v0.5.2 (2017-8-30)
-----------
* Feature: NAT Keepalive


v0.5.1 (2016-7-23)
-----------
* Fix: Free buffer
* Fix: Verify cipher length
* Fix: Running instance
* Feature: Reuse socket


v0.5.0 (2016-3-29)
-----------
* Feature: TCP support


v0.4.0 (2015-12-05)
-----------
* Feature: Multiqueue support


v0.3.0 (2015-11-18)
-----------
* Feature: Android support


v0.2.0 (2015-8-29)
-----------
* Feature: Openwrt support


v0.1.0 (2015-8-29)
-----------
* The first public version.
